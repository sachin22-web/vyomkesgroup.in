import path from "path";
import { createServer } from "./index";
import * as express from "express";

const app = createServer();
const port = process.env.PORT || 3000;

// In production, serve the built SPA files
const __dirname = import.meta.dirname;
const distPath = path.join(__dirname, "../spa");

// Serve static files
app.use(express.static(distPath));

// Handle React Router - serve index.html for all non-API routes
  app.get(/^(?!\/api\/|\/health).*/, (req, res) => {
  // Don't serve index.html for API routes
  if (req.path.startsWith("/api/") || req.path.startsWith("/health")) {
    console.log(`[NODE-BUILD] API path not found: ${req.path}`); // Added log
    return res.status(404).json({ error: "API endpoint not found" });
  }
  console.log(`[NODE-BUILD] Serving index.html for path: ${req.path}`); // Added log
  res.sendFile(path.join(distPath, "index.html"));
});

app.listen(Number(port), "0.0.0.0", () => {
  console.log(`🚀 Fusion Starter server running on port ${port}`);
  console.log(`📱 Frontend: http://localhost:${port}`);
  console.log(`🔧 API: http://localhost:${port}/api`);
});